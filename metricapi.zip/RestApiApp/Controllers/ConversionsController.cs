﻿using System;
using System.Net;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using RestApiApp.Core;
using RestApiApp.Core.Interfaces;
using RestApiApp.Models;

namespace RestApiApp.Controllers;

[ApiController]
[Route("[controller]")]
public class ConversionsController : ControllerBase
{
    private readonly IUnitOfWork _unitOfWork;

    public ConversionsController(IUnitOfWork unitOfWork)
    {
        _unitOfWork = unitOfWork;
    }

    [HttpGet]
    public async Task<IActionResult> Get()
    {
        var conversions = await _unitOfWork.Conversions.All();
        return Ok(conversions);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetUnit(int id)
    {
        var conversion = await _unitOfWork.Conversions.Get(id);
        if (conversion == null)
        {
            return NotFound();
        }
        else
        {
            return Ok(conversion);
        }
    }

    [HttpGet("convertable/{id}")]
    public async Task<IActionResult> GetConvertableToUnits(int id)
    {
        var list = await _unitOfWork.Conversions.GetConvertableToUnits(id);
        return Ok(list);
    }

    [HttpGet("convert/{value}/{from}/{to}")]
    public async Task<IActionResult> Convert(int value, int from, int to)
    {
        var conversionResult = await _unitOfWork.Conversions.Convert(value, from, to);
        if (conversionResult == null)
        {
            return NotFound(conversionResult);
        }
        else
        {
            return Ok(conversionResult);
        }
    }

    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [HttpPost]
    public async Task<IActionResult> Post(Conversion conversion)
    {
        int userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
        conversion.beforeAdd(1);
        await _unitOfWork.Conversions.Add(conversion, userId);
        await _unitOfWork.CompleteAsync();

        return Ok();
    }

    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [HttpPatch]
    public async Task<IActionResult> Update(Conversion conversion)
    {
        var existingConversion = await _unitOfWork.Conversions.Get(conversion.Id);
        if (existingConversion == null)
        {
            return NotFound();
        }

        existingConversion.FromUnitId = conversion.FromUnitId;
        existingConversion.ToUnitId = conversion.ToUnitId;
        existingConversion.Multiplier = conversion.Multiplier;

        int userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
        existingConversion.beforeUpdate(userId);
        
        await _unitOfWork.Conversions.Update(existingConversion, userId);
        return Ok();
    }

    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [HttpDelete]
    [Route("Hide")]
    public async Task<IActionResult> Hide(int id)
    {
        var conversion = await _unitOfWork.Conversions.Get(id);
        if (conversion == null)
        {
            return NotFound();
        }

        int userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
        conversion.beforeHidding(userId);
        await _unitOfWork.Conversions.Hide(conversion, userId);
        await _unitOfWork.CompleteAsync();
        return NoContent();
    }

    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [HttpDelete]
    public async Task<IActionResult> Delete(int id)
    {
        var conversion = await _unitOfWork.Conversions.Get(id);
        if (conversion == null)
        {
            return NotFound();
        }

        int userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
        await _unitOfWork.Conversions.Delete(conversion, userId);
        await _unitOfWork.CompleteAsync();
        return NoContent();
    }


}

