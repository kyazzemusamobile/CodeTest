﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using RestApiApp.Configs;
using RestApiApp.Models.Processes;

namespace RestApiApp.Controllers;

[ApiController]
[Route("[controller]")]
public class AuthenticationController: ControllerBase
{
    private readonly UserManager<IdentityUser> _userManger;
    private readonly IConfiguration _configuration;

    public AuthenticationController(UserManager<IdentityUser> userManger, IConfiguration configuration)
    {
        _userManger = userManger;
        _configuration = configuration;
    }

    [HttpPost]
    [Route("Register")]
    public async Task<IActionResult> Register([FromBody] Registration data)
    {
        //validate the post data
        if (ModelState.IsValid)
        {
            //check if the email is already in use
            var userWithEmail = await _userManger.FindByEmailAsync(data.Email);
            if(userWithEmail != null)
            {
                //email is already in use
                return BadRequest(new AuthResult()
                {
                    Result = false,
                    Errors = new List<string>() { "Email address already taken" }
                });
            }
            //user can be registered
            var user = new IdentityUser()
            {
                Email = data.Email,
                UserName = data.Name
            };
            var results = await _userManger.CreateAsync(user, data.Password);
            if (results.Succeeded)
            {
                var token = GenerateToken(user);
                return Ok(new AuthResult()
                {
                    Result = true,
                    token = token
                });
            }

            return BadRequest(new AuthResult()
            {
                Result = false,
                Errors = new List<string>() { "Something wrong happened, may be a server error" }
            });
        }

        return BadRequest();
    }

    private string GenerateToken(IdentityUser user)
    {
        var handler = new JwtSecurityTokenHandler();
        var key = Encoding.UTF8.GetBytes(_configuration.GetSection("JwtConfig:Secret").Value);
        var tokenDetails = new SecurityTokenDescriptor()
        {
            Subject = new ClaimsIdentity(new []
            {
                new Claim("Id", user.Id),
                new Claim(JwtRegisteredClaimNames.Email, user.Email),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(JwtRegisteredClaimNames.Iat, DateTime.Now.ToUniversalTime().ToString())
            }),
            Expires = DateTime.Now.AddHours(24),
            SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256)
        };
        var token = handler.CreateToken(tokenDetails);
        var theToken = handler.WriteToken(token);
        return theToken;
    }

    [HttpPost]
    [Route("Login")]
    public async Task<IActionResult> Login([FromBody] Login data)
    {
        if (ModelState.IsValid)
        {
            var userWithEmail = await _userManger.FindByEmailAsync(data.Email);
            if (userWithEmail == null)
            {
                return BadRequest(new AuthResult()
                {
                    Result = false,
                    Errors = new List<string>() { "Invalid credentials" }
                });
            }
            var userIsCorrect = await _userManger.CheckPasswordAsync(userWithEmail, data.Password);
            if (!userIsCorrect)
            {
                return BadRequest(new AuthResult()
                {
                    Result = false,
                    Errors = new List<string>() { "Invalid credentials supplied" }
                });
            }
            var token = GenerateToken(userWithEmail);
            return Ok(new AuthResult()
            {
                Result = true,
                token = token
            });
        }

        return BadRequest(new AuthResult()
        {
            Result = false,
            Errors = new List<string>() { "Invalid supplied credentials" }
        });
    }
}

