﻿using System;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RestApiApp.Core;
using RestApiApp.Core.Interfaces;
using RestApiApp.Models;

namespace RestApiApp.Controllers;


[ApiController]
[Route("[controller]")]
public class UnitsController: ControllerBase
{
    private readonly IUnitOfWork _unitOfWork;

    public UnitsController(IUnitOfWork unitOfWork)
    {
        _unitOfWork = unitOfWork;
    }

    [HttpGet]
    public async Task<IActionResult> Get()
    {
        var units = await _unitOfWork.Units.All();
        return Ok(units);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetUnit(int id)
    {
        var unit = await _unitOfWork.Units.Get(id);
        if(unit == null){
            return NotFound();
        }
        else
        {
            return Ok(unit);
        }
    }

    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [HttpPost]
    public async Task<IActionResult> Post(Unit unit)
    {
        int userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
        unit.beforeAdd(1);
        await _unitOfWork.Units.Add(unit, userId);
        await _unitOfWork.CompleteAsync();
        return Ok();
    }

    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [HttpPatch]
    public async Task<IActionResult> Update(Unit unit)
    {
        var existingUint = await _unitOfWork.Units.Get(unit.Id);
        if (existingUint == null)
        {
            return NotFound();
        }

        existingUint.Name = unit.Name;
        existingUint.Symbol = unit.Symbol;

        int userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
        existingUint.beforeUpdate(userId);
        await _unitOfWork.Units.Update(existingUint, userId);
        return Ok();
    }

    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [HttpDelete]
    [Route("Hide")]
    public async Task<IActionResult> Hide(int id)
    {
        var unit = await _unitOfWork.Units.Get(id);
        if (unit == null)
        {
            return NotFound();
        }

        int userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
        unit.beforeHidding(userId);
        await _unitOfWork.Units.Hide(unit, userId);
        await _unitOfWork.CompleteAsync();
        return NoContent();
    }

    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [HttpDelete]
    public async Task<IActionResult> Delete(int id)
    {
        var unit = await _unitOfWork.Units.Get(id);
        if (unit == null)
        {
            return NotFound();
        }

        int userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);
        await _unitOfWork.Units.Delete(unit, userId);
        await _unitOfWork.CompleteAsync();
        return NoContent();
    }


}

