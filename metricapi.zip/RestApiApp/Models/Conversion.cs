﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace RestApiApp.Models;

public class Conversion: Common
{
    [Key]
    public int FromUnitId { get; set; }
    [Key]
    public int ToUnitId { get; set; }
    public Decimal Multiplier { get; set; }
    public String? Formular { get; set; }

    [ForeignKey("FromUnitId")]
    public Unit FromUnit { get; set; }

    [ForeignKey("ToUnitId")]
    public Unit ToUnit { get; set; }
}


