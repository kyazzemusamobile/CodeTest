﻿using System;
namespace RestApiApp.Models;

public class UserActionLog: Common
{
    public int UserId { get; set; }
    public string Action { get; set; }
    public string Payload { get; set; }
}

