﻿using System;
namespace RestApiApp.Models;


public class Unit: Common
{
    public string Name { get; set; }
    public string Symbol { get; set; }

    public virtual ICollection<Conversion> FromConversions { get; set; }
    public virtual ICollection<Conversion> ToConversions { get; set; }
}


