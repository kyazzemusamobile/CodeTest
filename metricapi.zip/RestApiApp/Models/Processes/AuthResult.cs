﻿using System;
namespace RestApiApp.Models.Processes;

public class AuthResult
{
    public string token { get; set; }
    public bool Result { get; set; }
    public List<string> Errors { get; set; }
}

 