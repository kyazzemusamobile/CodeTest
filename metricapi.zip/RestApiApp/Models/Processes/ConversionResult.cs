﻿using System;
namespace RestApiApp.Models.Processes;

public class ConversionResult
{ 
    public decimal FromValue { get; set; }
    public int FromId { get; set; }
    public int ToId { get; set; }
    public decimal? ToValue { get; set; } = null;
    public bool IsConversionAvailable { get; set; } = false;
    public string? ErrorMessage { get; set; } = null;
}

