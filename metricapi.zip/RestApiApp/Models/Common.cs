﻿using System;
namespace RestApiApp.Models;

public class Common
{
    public int Id { get; set; }
    public int Status { get; set; }
    public int CreatedBy { get; set; }
    public DateTime CreatedDate { get; set; }
    public int ModifiedBy { get; set; }
    public DateTime ModifiedDate { get; set; }

    /// <summary>
    ///  This method is to called before adding the entity
    /// </summary>
    /// <param name="entity">The object to be inserted into the db</param>
    /// <param name="userId">The id of the user executing this operation</param>
    /// <returns>Updated Object</returns>
    public void beforeAdd(int userId)
    {
        this.CreatedBy = userId;
        this.CreatedDate = DateTime.Now.ToUniversalTime();
        this.ModifiedBy = userId;
        this.ModifiedDate = DateTime.Now.ToUniversalTime();
        this.Status = 1;
    }

    /// <summary>
    ///  This method is to called before updating the entity
    /// </summary>
    /// <param name="entity">The object to be updated</param>
    /// <param name="userId">The id of the user executing this operation</param>
    /// <returns>Updated Object</returns>
    public void beforeUpdate(int userId)
    {
        this.ModifiedBy = userId;
        this.ModifiedDate = DateTime.Now.ToUniversalTime();
    }

    /// <summary>
    ///  This method is to called before marking the entity as hidden
    /// </summary>
    /// <param name="entity">The object to be updated</param>
    /// <param name="userId">The id of the user executing this operation</param>
    /// <returns>Updated Object</returns>
    public void beforeHidding(int userId)
    {
        beforeUpdate(userId);
    }
}


