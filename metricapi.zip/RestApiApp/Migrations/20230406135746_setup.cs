﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace RestApiApp.Migrations
{
    /// <inheritdoc />
    public partial class setup : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AspNetRoles",
                columns: table => new
                {
                    Id = table.Column<string>(type: "text", nullable: false),
                    Name = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    NormalizedName = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUsers",
                columns: table => new
                {
                    Id = table.Column<string>(type: "text", nullable: false),
                    UserName = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    NormalizedUserName = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    Email = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    NormalizedEmail = table.Column<string>(type: "character varying(256)", maxLength: 256, nullable: true),
                    EmailConfirmed = table.Column<bool>(type: "boolean", nullable: false),
                    PasswordHash = table.Column<string>(type: "text", nullable: true),
                    SecurityStamp = table.Column<string>(type: "text", nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "text", nullable: true),
                    PhoneNumber = table.Column<string>(type: "text", nullable: true),
                    PhoneNumberConfirmed = table.Column<bool>(type: "boolean", nullable: false),
                    TwoFactorEnabled = table.Column<bool>(type: "boolean", nullable: false),
                    LockoutEnd = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    LockoutEnabled = table.Column<bool>(type: "boolean", nullable: false),
                    AccessFailedCount = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUsers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Units",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Name = table.Column<string>(type: "text", nullable: false),
                    Symbol = table.Column<string>(type: "text", nullable: false),
                    Status = table.Column<int>(type: "integer", nullable: false),
                    CreatedBy = table.Column<int>(type: "integer", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    ModifiedBy = table.Column<int>(type: "integer", nullable: false),
                    ModifiedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Units", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "UserActionLogs",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    UserId = table.Column<int>(type: "integer", nullable: false),
                    Action = table.Column<string>(type: "text", nullable: false),
                    Payload = table.Column<string>(type: "text", nullable: false),
                    Status = table.Column<int>(type: "integer", nullable: false),
                    CreatedBy = table.Column<int>(type: "integer", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    ModifiedBy = table.Column<int>(type: "integer", nullable: false),
                    ModifiedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserActionLogs", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AspNetRoleClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    RoleId = table.Column<string>(type: "text", nullable: false),
                    ClaimType = table.Column<string>(type: "text", nullable: true),
                    ClaimValue = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoleClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetRoleClaims_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    UserId = table.Column<string>(type: "text", nullable: false),
                    ClaimType = table.Column<string>(type: "text", nullable: true),
                    ClaimValue = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetUserClaims_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserLogins",
                columns: table => new
                {
                    LoginProvider = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                    ProviderKey = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                    ProviderDisplayName = table.Column<string>(type: "text", nullable: true),
                    UserId = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserLogins", x => new { x.LoginProvider, x.ProviderKey });
                    table.ForeignKey(
                        name: "FK_AspNetUserLogins_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserRoles",
                columns: table => new
                {
                    UserId = table.Column<string>(type: "text", nullable: false),
                    RoleId = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserRoles", x => new { x.UserId, x.RoleId });
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserTokens",
                columns: table => new
                {
                    UserId = table.Column<string>(type: "text", nullable: false),
                    LoginProvider = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                    Name = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                    Value = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserTokens", x => new { x.UserId, x.LoginProvider, x.Name });
                    table.ForeignKey(
                        name: "FK_AspNetUserTokens_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Conversions",
                columns: table => new
                {
                    FromUnitId = table.Column<int>(type: "integer", nullable: false),
                    ToUnitId = table.Column<int>(type: "integer", nullable: false),
                    Multiplier = table.Column<decimal>(type: "numeric", nullable: false),
                    Formular = table.Column<string>(type: "text", nullable: true),
                    Id = table.Column<int>(type: "integer", nullable: false),
                    Status = table.Column<int>(type: "integer", nullable: false),
                    CreatedBy = table.Column<int>(type: "integer", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    ModifiedBy = table.Column<int>(type: "integer", nullable: false),
                    ModifiedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Conversions", x => new { x.FromUnitId, x.ToUnitId });
                    table.ForeignKey(
                        name: "FK_Conversions_Units_FromUnitId",
                        column: x => x.FromUnitId,
                        principalTable: "Units",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Conversions_Units_ToUnitId",
                        column: x => x.ToUnitId,
                        principalTable: "Units",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Units",
                columns: new[] { "Id", "CreatedBy", "CreatedDate", "ModifiedBy", "ModifiedDate", "Name", "Status", "Symbol" },
                values: new object[,]
                {
                    { 1, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(1910), 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(1970), "Kilometer", 1, "km" },
                    { 2, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(1980), 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(1980), "Meters", 1, "m" },
                    { 3, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2010), 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2010), "Mile", 1, "mi" },
                    { 4, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2020), 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2020), "Kilogrammes", 1, "kg" },
                    { 5, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2030), 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2030), "Grammes", 1, "g" },
                    { 6, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2040), 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2040), "Pound", 1, "lb" },
                    { 7, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2050), 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2050), "Liters", 1, "l" },
                    { 8, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2060), 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2060), "Milliliter ", 1, "ml" },
                    { 9, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2060), 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2070), "Gallon", 1, "gal" },
                    { 10, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2070), 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2080), "Celsius", 1, "c" },
                    { 11, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2080), 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2090), "Fahrenheit", 1, "f" }
                });

            migrationBuilder.InsertData(
                table: "Conversions",
                columns: new[] { "FromUnitId", "ToUnitId", "CreatedBy", "CreatedDate", "Formular", "Id", "ModifiedBy", "ModifiedDate", "Multiplier", "Status" },
                values: new object[,]
                {
                    { 1, 2, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2120), null, 1, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2120), 1000m, 1 },
                    { 1, 3, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2140), null, 3, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2150), 0.621371m, 1 },
                    { 2, 1, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2130), null, 2, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2140), 0.001m, 1 },
                    { 3, 1, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2150), null, 4, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2160), 1.60934m, 1 },
                    { 10, 11, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2160), "CelsiusToFahrenheit", 5, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2170), 0m, 1 },
                    { 11, 10, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2170), "FahrenheitCelsiusTo", 6, 0, new DateTime(2023, 4, 6, 13, 57, 46, 880, DateTimeKind.Utc).AddTicks(2180), 0m, 1 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_AspNetRoleClaims_RoleId",
                table: "AspNetRoleClaims",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "RoleNameIndex",
                table: "AspNetRoles",
                column: "NormalizedName",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserClaims_UserId",
                table: "AspNetUserClaims",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserLogins_UserId",
                table: "AspNetUserLogins",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserRoles_RoleId",
                table: "AspNetUserRoles",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "EmailIndex",
                table: "AspNetUsers",
                column: "NormalizedEmail");

            migrationBuilder.CreateIndex(
                name: "UserNameIndex",
                table: "AspNetUsers",
                column: "NormalizedUserName",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Conversions_ToUnitId",
                table: "Conversions",
                column: "ToUnitId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AspNetRoleClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserLogins");

            migrationBuilder.DropTable(
                name: "AspNetUserRoles");

            migrationBuilder.DropTable(
                name: "AspNetUserTokens");

            migrationBuilder.DropTable(
                name: "Conversions");

            migrationBuilder.DropTable(
                name: "UserActionLogs");

            migrationBuilder.DropTable(
                name: "AspNetRoles");

            migrationBuilder.DropTable(
                name: "AspNetUsers");

            migrationBuilder.DropTable(
                name: "Units");
        }
    }
}
