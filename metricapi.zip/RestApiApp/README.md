﻿# Metric API

When the app runns, it opens a swagger documentation page that has docs of all the available end points
Endpoints that create a change in the db are all Authorised and the user action are logged

## Seeding

When the database is being auto created, some initial data is automatically inserted into the db

## Design Descisions & Best Practices

In the conversion table we use composite keys so the a From-To relationship is allowed to happen only once

Authentication tables are controlled by the Identity framework so we use it in a blac box maner and get all the available and tested functionality for free

* **Unit Of Work and the repository** pattern have been implemented to decouple/separate concerns
* This helps us to do unit tests with mocking the db without using our reall db
* Also abstrating the data access layer means that we can switch our db storage to any database without changing our business logic code


## Usage Note

EndPoints that modify the database like create and edit need authorization
All data fetching endpoints (Reading Data), donot need authorization

Preserving of Data - Shallow Deleting
Hide a data record doesnot actually delete it but marks it as status = 0, meaning that it should not show up
any more in our result sets and related child records.

Deleting end point actually removes the record and related child entries

## Accurancy

In the conversion entity we use the decimal datatype which allows for better
accuracy.
//put link to descrioptio

## Data Consistence

* The db coontext specifices that when a unit is removed, all the conversions have to be removed
* When a conversion is removed, none of the parent units are not removed

## To Update DB

`dotnet-ef migrations add "migration name"`

`dotnet-ef database update`

## Authentication

We use JWT tokens for authentication because we want the API to be RESTFUl, so we dont store user cookies/sessions

We generated the random string from [this site](https://onlinetools.com/random/generate-random-string) used in the config,
then sprinkled it with random numbers and removed other charatcters

## Security

For development purposes, our keys and other configurations have been put into the app config, but it would be better
to use an environment file (.env) or some toher more secure service in production

The tokens dont expire and are not refreshed

During registration the user is not required to vaerify the email, to simplify the solution but in production this would
have been implemented in such a way that the user has to verify the email

Emails are also not validated for formats but in production this would need to be implemented


## Unit Tests

We are using xUnit

## Dot net version
6.0.302