﻿using System;
namespace RestApiApp.Configs;

public class JwtConfig
{
    public String Secret { get; set; }
}

