﻿using System;
using RestApiApp.Core.Interfaces;
using RestApiApp.Models;

namespace RestApiApp.Core;

public class UnitOfWork: IUnitOfWork, IDisposable
{

    public readonly ApiDbContext _context;

    public IUnitRepository Units { get; private set;  }

    public IConversionRepository Conversions { get; private set; }

    public UnitOfWork(ApiDbContext context)
    {

        _context = context;
        Units = new UnitRepository(_context);
        Conversions = new ConversionRepository(_context);
    }

    public async Task CompleteAsync()
    {
        await _context.SaveChangesAsync();
    }

    public void Dispose()
    {
        _context.Dispose();
    }
}

