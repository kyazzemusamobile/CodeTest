﻿using System;
using Microsoft.EntityFrameworkCore;
using RestApiApp.Core.Interfaces;
using RestApiApp.Models;

namespace RestApiApp.Core;

public class UnitRepository: GenericRepository<Unit>, IUnitRepository
{
    public UnitRepository(ApiDbContext context) : base(context)
    {
    }

    /// <summary>
    ///     Returns a unit
    ///     This overide tells EF no to truck the object because we are in a REST api
    /// </summary>
    /// <param name="id">The unit's id</param>
    /// <returns>Unit</returns>
    public override async Task<Unit?> Get(int id)
    {
        try
        {
            return await _context.Units.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        }
        catch (Exception ex)
        {
            throw;
        }
    }
}

