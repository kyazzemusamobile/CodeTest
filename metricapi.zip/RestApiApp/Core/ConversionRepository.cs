﻿using System;
using Microsoft.EntityFrameworkCore;
using RestApiApp.Core.Interfaces;
using RestApiApp.Models;
using RestApiApp.Models.Processes;

namespace RestApiApp.Core;

public class ConversionRepository : GenericRepository<Conversion>, IConversionRepository
{
    public ConversionRepository(ApiDbContext context) : base(context)
    {
    }

    /// <summary>
    ///     Return a conversion
    ///     This overide tells EF no to truck the object because we are in a REST api
    /// </summary>
    /// <param name="id">The conversion id</param>
    /// <returns>Conversion</returns>
    public override async Task<Conversion?> Get(int id)
    {
        try
        {
            return await _context.Conversions.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    /// <summary>
    ///     Gets the units that are convertible to the queried unit id
    /// </summary>
    /// <param name="id">unit id</param>
    /// <returns>List Of Related Units</returns>
    public async Task<IEnumerable<Unit>> GetConvertableToUnits(int id)
    {
        var results = _context.Conversions
            .Where(c => c.FromUnitId == id)
            .Include(c => c.ToUnit)
            .ToList()
            .Select(x => x.ToUnit);

        return results;
    }

    /// <summary>
    ///     Converts FromValue of From Unit to another value of ToUnit 
    /// </summary>
    /// <param name="fromValue">From Value</param>
    /// <param name="fromValueUnitId">From Unit</param>
    /// <param name="toUnitId">To Unit</param>
    /// <returns>ConversionResult</returns>
    public async Task<ConversionResult> Convert(decimal fromValue, int fromValueUnitId, int toUnitId)
    {
        var result = new ConversionResult()
        {
            FromId = fromValueUnitId,
            FromValue = fromValue,
            ToId = toUnitId
        };
        var conversion = _context.Conversions
            .FirstOrDefault(c => c.FromUnitId == fromValueUnitId);
        if (conversion == null)
        {
            result.ToValue = null;
            result.IsConversionAvailable = false;
            result.ErrorMessage = "Conversion does not exist on the api or is impossible";
        }
        else
        {
            if(conversion.Formular != null && conversion.Formular.Length > 0)
            {
                //use a formula
                var toValue = Converter.Convert(conversion.Formular, fromValue);
                result.ToValue = toValue;
            }
            else
            {
                //e.g convert 2m to km
                //db entry: 1m = 0.001 km (1/1000)
                //so 2m => (0.001 * 2) km
                var toValue = conversion.Multiplier * fromValue;
                result.ToValue = toValue;
            }
            result.IsConversionAvailable = true;
            result.ErrorMessage = null;
        }

        return result;
    }
}


