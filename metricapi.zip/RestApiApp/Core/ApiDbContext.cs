﻿using System;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using RestApiApp.Models;

namespace RestApiApp.Core;

public class ApiDbContext: IdentityDbContext 
{
    public virtual DbSet<Unit> Units { get; set; }
    public virtual DbSet<Conversion> Conversions { get; set; }
    public virtual DbSet<UserActionLog> UserActionLogs { get; set; }

    public ApiDbContext(DbContextOptions<ApiDbContext> options): base(options)
    {

    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        //add a composite key constraint
        modelBuilder.Entity<Conversion>().HasKey(table => new {
            table.FromUnitId,
            table.ToUnitId
        });

        //When a conversion is deleted, the parent should not be deleted
        modelBuilder.Entity<Conversion>(entity =>
        {
            entity.HasOne(c => c.FromUnit)
            .WithMany(u => u.FromConversions)
            .HasForeignKey(x => x.FromUnitId)
            .OnDelete(DeleteBehavior.NoAction);

            entity.HasOne(c => c.ToUnit)
            .WithMany(u => u.ToConversions)
            .HasForeignKey(x => x.ToUnitId)
            .OnDelete(DeleteBehavior.NoAction);
        });

        //When a unit is deleted deleted all the conversions
        modelBuilder.Entity<Unit>(entity =>
        {
            entity.HasMany(c => c.FromConversions)
            .WithOne(u => u.FromUnit)
            .OnDelete(DeleteBehavior.Cascade);

            entity.HasMany(c => c.ToConversions)
            .WithOne(u => u.ToUnit)
            .OnDelete(DeleteBehavior.Cascade);
        });

        ApiDbContext.Seed(modelBuilder);
    }

    /// <summary>
    ///     This applyies seeding intial data when the db has just been created
    /// </summary>
    /// <param name="modelBuilder">ModelBuilder</param>
    private static void Seed(ModelBuilder modelBuilder)
    {

        modelBuilder.Entity<Unit>().HasData(
            beforeAdding(new Unit
            {
                Id = 1,
                Name = "Kilometer",
                Symbol = "km"
            }),
            beforeAdding(new Unit{
                Id = 2,
                Name = "Meters",
                Symbol = "m"
            }),
            beforeAdding(new Unit
            {
                Id = 3,
                Name = "Mile",
                Symbol = "mi"
            }),
            beforeAdding(new Unit
            {
                Id = 4,
                Name = "Kilogrammes",
                Symbol = "kg"
            }),
            beforeAdding(new Unit
            {
                Id = 5,
                Name = "Grammes",
                Symbol = "g"
            }),
            beforeAdding(new Unit
            {
                Id = 6,
                Name = "Pound",
                Symbol = "lb"
            }),
            beforeAdding(new Unit
            {
                Id = 7,
                Name = "Liters",
                Symbol = "l"
            }),
            beforeAdding(new Unit
            {
                Id = 8,
                Name = "Milliliter ",
                Symbol = "ml"
            }),
            beforeAdding(new Unit
            {
                Id = 9,
                Name = "Gallon",
                Symbol = "gal"
            }),
            beforeAdding(new Unit
            {
                Id = 10,
                Name = "Celsius",
                Symbol = "c"
            }),
            beforeAdding(new Unit
            {
                Id = 11,
                Name = "Fahrenheit",
                Symbol = "f"
            })
        );

        //some conversions
        modelBuilder.Entity<Conversion>().HasData(
            //1 km = 1000 m
            beforeAdding(new Conversion
            {
                Id = 1,
                FromUnitId = 1,
                ToUnitId = 2,
                Multiplier = 1000
            }),
            //1 m = 1/1000 km
            beforeAdding(new Conversion
            {
                Id = 2,
                FromUnitId = 2,
                ToUnitId = 1,
                Multiplier = new decimal(0.001)
            }),
            //1 km = 1000 mile
            beforeAdding(new Conversion
            {
                Id = 3,
                FromUnitId = 1,
                ToUnitId = 3,
                Multiplier = new decimal(0.621371)
            }),
            //1 mile = 1.60934 km
            beforeAdding(new Conversion
            {
                Id = 4,
                FromUnitId = 3,
                ToUnitId = 1,
                Multiplier = new decimal(1.60934)
            }),
            //1 deg cel = (1°C × 9/5) + 32
            beforeAdding(new Conversion
            {
                Id = 5,
                FromUnitId = 10,
                ToUnitId = 11,
                Multiplier = 0,
                Formular = Converter.CelsiusToFahrenheit
            }),
            //1 deg fah = (1°F − 32) × 5/9 
            beforeAdding(new Conversion
            {
                Id = 6,
                FromUnitId = 11,
                ToUnitId = 10,
                Multiplier = 0,
                Formular = Converter.FahrenheitCelsiusTo
            })
        );
        
    }

    private static Object beforeAdding(Common item)
    {
        item.beforeAdd(0);
        return item;
    }
    
}

