﻿using System;
using RestApiApp.Models;
using RestApiApp.Models.Processes;

namespace RestApiApp.Core.Interfaces;

public interface IConversionRepository : IGenericRepository<Conversion>
{
    Task<IEnumerable<Unit>> GetConvertableToUnits(int id);
    Task<ConversionResult> Convert(Decimal fromValue, int fromValueUnitId, int toUnitId);
}

    
