﻿using System;
namespace RestApiApp.Core.Interfaces;

public interface IGenericRepository<T> where T : class
{
    Task<IEnumerable<T>> All();
    Task<T?> Get(int id);
    Task<bool> Add(T entity, int userId);
    Task<bool> Update(T entity, int userId);
    Task<bool> Hide(T entity, int userId);
    Task<bool> Delete(T entity, int userId);
}

