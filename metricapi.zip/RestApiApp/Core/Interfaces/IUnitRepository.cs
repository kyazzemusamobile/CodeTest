﻿using System;
using RestApiApp.Models;

namespace RestApiApp.Core.Interfaces;

public interface IUnitRepository: IGenericRepository<Unit>
{
    
}

