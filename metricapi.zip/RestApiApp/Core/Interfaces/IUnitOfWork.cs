﻿using System;
namespace RestApiApp.Core.Interfaces;

public interface IUnitOfWork
{
    IUnitRepository Units { get;  }
    IConversionRepository Conversions { get;  }
    Task CompleteAsync();
}

