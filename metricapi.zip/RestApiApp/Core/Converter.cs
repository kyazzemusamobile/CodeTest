﻿using System;
namespace RestApiApp.Core;

public static class Converter
{
    public const string CelsiusToFahrenheit = "CelsiusToFahrenheit";
    public const string FahrenheitCelsiusTo = "FahrenheitCelsiusTo";
    

    public static Decimal? Convert(string formulaName, Decimal value )
    {
        switch (formulaName)
        {
            case Converter.CelsiusToFahrenheit:
                return (value * (9 / 5)) + 32;
            case Converter.FahrenheitCelsiusTo:
                return (value -  32) * (5 / 9);
            default:
                break;
        }
        return null;
    }
}

