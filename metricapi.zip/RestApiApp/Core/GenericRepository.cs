﻿using System;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using RestApiApp.Core.Interfaces;
using RestApiApp.Models;

namespace RestApiApp.Core;

public class GenericRepository<T> : IGenericRepository<T> where T : class
{
    protected ApiDbContext _context;
    internal DbSet<T> _dbSet;

    public GenericRepository(ApiDbContext context)
    {
        _context = context;
        _dbSet = _context.Set<T>();
    }

    public virtual async Task<bool> Add(T entity, int userId)
    {
        await _dbSet.AddAsync(entity);
        //log user activity
        log(userId, "Added", entity);
        return true;
    }

    public virtual async Task<IEnumerable<T>> All()
    {
        return await _dbSet.AsNoTracking().ToListAsync(); 
    }

    public virtual async Task<bool> Delete(T entity, int userId)
    {
        _dbSet.Remove(entity);
        //log user activity
        log(userId, "Deleted", entity);
        return true;
    }

    public virtual async Task<T?> Get(int id)
    {
        return await _dbSet.FindAsync(id);
    }

    public virtual async Task<bool> Hide(T entity, int userId)
    {
        _dbSet.Update(entity);
        //log user activity
        log(userId, "Deactivated", entity);
        return true;
    }

    public virtual async Task<bool> Update(T entity, int userId)
    {
        _dbSet.Update(entity);
        //log user activity
        log(userId, "Updated", entity);
        return true;
    }

    private void log(int userId, string action,  T entity)
    {
        Type typeParameterType = typeof(T);
        var log = new UserActionLog()
        {
            UserId = userId,
            Action = action + " " + typeParameterType,
            Payload = JsonConvert.ToString(entity.ToString())
        };
        log.beforeAdd(userId);
        _context.UserActionLogs.Add(log);
    }

}

